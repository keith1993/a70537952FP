#!/bin/bash

source buildconfig.env
grunt test
